
  # Web Kelurahan Cipete Selatan

  This is a code bundle for Web Kelurahan Cipete Selatan. The original project is available at https://www.figma.com/design/tLQDqcF5xmeUbbbgIGzwQj/Web-Kelurahan-Cipete-Selatan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  