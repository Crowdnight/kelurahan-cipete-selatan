import { createBrowserRouter, redirect } from "react-router";
import { Root } from "./components/Root";
import { Beranda } from "./components/Beranda";
import { Media } from "./components/Media";
import { Dokumentasi } from "./components/Dokumentasi";
import { Anggota } from "./components/Anggota";
import { ContactUs } from "./components/ContactUs";
import { Login } from "./components/Login";

function requireAuth() {
  if (!localStorage.getItem("cipsel_logged_in")) {
    return redirect("/login");
  }
  return null;
}

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    Component: Root,
    loader: requireAuth,
    children: [
      { index: true, Component: Beranda },
      { path: "media", Component: Media },
      { path: "dokumentasi", Component: Dokumentasi },
      { path: "anggota", Component: Anggota },
      { path: "contact", Component: ContactUs },
    ],
  },
]);
