import { Outlet, NavLink } from "react-router";
import { Home, FileText, Image, Phone, Users } from "lucide-react";
import logoJakarta from "../../imports/image-0.png";

export function Root() {
  return (
    <div className="min-h-screen bg-[#F5E6D3] flex flex-col">
      {/* Header */}
      <header className="bg-[#8B6F47] text-white shadow-lg">
        <div className="container mx-auto px-4 py-4 md:py-6 flex items-center justify-between gap-2">
          <div className="flex-1 min-w-0">
            <h1 className="text-lg sm:text-2xl md:text-3xl font-bold truncate">Kelurahan Cipete Selatan</h1>
            <p className="text-xs sm:text-sm text-[#F5E6D3] mt-1 truncate">Kota Administrasi Jakarta Selatan</p>
          </div>
          <img
            src={logoJakarta}
            alt="Logo Jakarta"
            className="h-12 sm:h-16 md:h-20 w-auto object-contain flex-shrink-0"
          />
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-[#A0826D] shadow-md sticky top-0 z-10">
        <div className="container mx-auto px-2 sm:px-4">
          <ul className="flex justify-between sm:justify-start sm:space-x-1 overflow-x-auto">
            <li className="flex-shrink-0">
              <NavLink
                to="/"
                end
                className={({ isActive }) =>
                  `flex flex-col sm:flex-row items-center gap-1 sm:gap-2 px-2 sm:px-4 md:px-6 py-3 sm:py-4 transition-colors ${
                    isActive
                      ? "bg-[#8B6F47] text-white"
                      : "text-white hover:bg-[#8B6F47]/80"
                  }`
                }
              >
                <Home size={18} className="sm:w-5 sm:h-5" />
                <span className="text-xs sm:text-sm md:text-base">Beranda</span>
              </NavLink>
            </li>
            <li className="flex-shrink-0">
              <NavLink
                to="/media"
                className={({ isActive }) =>
                  `flex flex-col sm:flex-row items-center gap-1 sm:gap-2 px-2 sm:px-4 md:px-6 py-3 sm:py-4 transition-colors ${
                    isActive
                      ? "bg-[#8B6F47] text-white"
                      : "text-white hover:bg-[#8B6F47]/80"
                  }`
                }
              >
                <FileText size={18} className="sm:w-5 sm:h-5" />
                <span className="text-xs sm:text-sm md:text-base">Media</span>
              </NavLink>
            </li>
            <li className="flex-shrink-0">
              <NavLink
                to="/dokumentasi"
                className={({ isActive }) =>
                  `flex flex-col sm:flex-row items-center gap-1 sm:gap-2 px-2 sm:px-4 md:px-6 py-3 sm:py-4 transition-colors ${
                    isActive
                      ? "bg-[#8B6F47] text-white"
                      : "text-white hover:bg-[#8B6F47]/80"
                  }`
                }
              >
                <Image size={18} className="sm:w-5 sm:h-5" />
                <span className="text-xs sm:text-sm md:text-base">Dokumentasi</span>
              </NavLink>
            </li>
            <li className="flex-shrink-0">
              <NavLink
                to="/anggota"
                className={({ isActive }) =>
                  `flex flex-col sm:flex-row items-center gap-1 sm:gap-2 px-2 sm:px-4 md:px-6 py-3 sm:py-4 transition-colors ${
                    isActive
                      ? "bg-[#8B6F47] text-white"
                      : "text-white hover:bg-[#8B6F47]/80"
                  }`
                }
              >
                <Users size={18} className="sm:w-5 sm:h-5" />
                <span className="text-xs sm:text-sm md:text-base">Anggota</span>
              </NavLink>
            </li>
            <li className="flex-shrink-0">
              <NavLink
                to="/contact"
                className={({ isActive }) =>
                  `flex flex-col sm:flex-row items-center gap-1 sm:gap-2 px-2 sm:px-4 md:px-6 py-3 sm:py-4 transition-colors ${
                    isActive
                      ? "bg-[#8B6F47] text-white"
                      : "text-white hover:bg-[#8B6F47]/80"
                  }`
                }
              >
                <Phone size={18} className="sm:w-5 sm:h-5" />
                <span className="text-xs sm:text-sm md:text-base whitespace-nowrap">Contact</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6 md:py-8">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-[#6B5744] text-white py-6 mt-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">© 2026 Kelurahan Cipete Selatan. Semua hak dilindungi.</p>
        </div>
      </footer>
    </div>
  );
}