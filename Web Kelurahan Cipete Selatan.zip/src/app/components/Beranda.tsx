import { MapPin, Users, Building, LogOut } from "lucide-react";
import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router";

export function Beranda() {
  const navigate = useNavigate();
  const currentUser = localStorage.getItem("cipsel_user") ?? "";

  function handleLogout() {
    localStorage.removeItem("cipsel_logged_in");
    localStorage.removeItem("cipsel_user");
    navigate("/login", { replace: true });
  }

  const [displayedText1, setDisplayedText1] = useState("");
  const [displayedText2, setDisplayedText2] = useState("");
  const [showCursor1, setShowCursor1] = useState(true);
  const [showCursor2, setShowCursor2] = useState(false);
  const fullText1 = "Selamat Datang";
  const fullText2 = "Di Kelurahan Cipete Selatan";

  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex <= fullText1.length) {
        setDisplayedText1(fullText1.slice(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(interval);
        setShowCursor1(false);
        setShowCursor2(true);
        // Start second text animation
        let currentIndex2 = 0;
        const interval2 = setInterval(() => {
          if (currentIndex2 <= fullText2.length) {
            setDisplayedText2(fullText2.slice(0, currentIndex2));
            currentIndex2++;
          } else {
            clearInterval(interval2);
            setShowCursor2(false);
          }
        }, 80);
      }
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-8">
      {/* Logout button */}
      <div className="flex justify-between items-center">
        <span className="text-[#5A4A3A] text-sm">
          Halo, <span className="font-semibold text-[#8B6F47]">{currentUser}</span>
        </span>
        <motion.button
          onClick={handleLogout}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg shadow-md transition-colors text-sm"
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.97 }}
        >
          <LogOut size={16} />
          <span>Keluar</span>
        </motion.button>
      </div>

      {/* Hero Section */}
      <motion.div
        className="relative rounded-lg shadow-lg overflow-hidden border-2 border-[#D4A574]"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <img
       // src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExMWFhUXGB0ZGRcYFxgaGhgaHxgdGxcYHRoeHSggHR8nGxgXITIhJSkrLi4uHR8zODMtNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLystLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAFBgMEAAIHAQj/xABIEAACAQIEAwYCBwQHBgYDAAABAhEDIQAEEjEFQVEGEyIyYXGBkQcUQlKhscEj0eHwYnKCkrLS8RUkM0NTohc0VGNzoxaTwv/EABkBAAMBAQEAAAAAAAAAAAAAAAECAwAEBf/EACwRAAICAQMDAgUEAwAAAAAAAAABAhEhAxIxE0FRBGEiMnGRoUKBscEU4fD/2gAMAwEAAhEDEQA/AAeR7QVVhA9RV5aXax321QJuZHM4M1O02ZVAe/qkzEd4xn88IvFcrWpv3boVfeCQxI5EaSRHrON8twPM7qhiOTLb03tuccs6xLfQjGap28zi+E1HItzVtjylfQdMbUfpIzam1Rh6BUPP+l88Kpy9RCVcnUDcbxjanRZiFAkkgARckmw95xdaq5DZ03h30iV2pK5r0yxJBR0VSApEmRMyJ6ek4F8V7VPWNdjI1ugEQDCrp0TO0mpJUzf4gWmSp5amrPSDVmCOQ9lQMSIcbREWPiknaCMDaPEaZUKWKsXdiAoIGpiQACw68vbHO9SUsrgDdl5ePs37OqCTTMwhAB0eYyLxp1C3LGuTVizPQYERG3muCfNN9pv8hj2hxRUXwjUAbHuYhiPvcwRPgMAwbG+CHCc9lUJZFIncNqUr7RZt+Rn0OJylSwhS1nMzNOmAzKY0qGUSxkBQB9mT18Jj0OKuS4LmhVbMPSD+E/s6jKdRkX0xpiARp5Wj0ImlQZHdm0i8jTqHP2IME/wvNynnO7patXgVRAIfWREwB7bAn9cRjNrgOCvQpso7wppDDWKTglS1zAGnUN5MTz6YiXK1hWDiQppll03BMDyGxvqY3tzM3wG7V8SLvTZAAjeDXrBMGNSlRcRIm0z6ziVc2MsqnvNQk06mlJ0tAIDTG2oc1mABF4daclkU14pxylSq/tqbrU076EBgjlLAxJ2jGU+1GXP2mH9ZZ+WmcXM1nGrg0XGhHTUKmnURdTIEAi53sDHTCG9OqCQYMGIIE+xB222x1aM90aa4OmGq2h0TjuW/6n/Y8/4fbBbIdr+7/wCHmRA+zUOpY9mMj4EY5l3b/wDTT+6v6Y2UsP8Al/KR+WL34YXJPlHa8r2zoVFZKrBWJEsryp9T9pR7TbnbFPtVky6JVokOpMSotPM2/wBBtub8kp1yLaD/AHn/ADw1cL+kDNUaa0gQUUaVUpTaBaBNiee98PlqpEJaS/SdDyGac920XgBtvMsCAD1tf8MPAxxDKfSQ6f8AKpnbemRsTG1ToZP8nBan9LrR4qNP51B+h/k4q8knpSOs4izVQqjEbgE/hjm2W+l2n9uhb+i5n5Mg/PBfK/SBl80DSpJU1sIuFgDmZDE7TywNplozbpIdKD6lB6gH5jG+FGh2/wCHKAjV9JTwmVbcWOw9MX6PbPh7bZql8Tp/OMba/BNxYfxmKVHi2Xfy16Te1RD+uLaODsQfY4FANjhP7R5VqVOpWRf2pkByNRC3JI8XhN28QiAPTDhgZxzhxrJAYgRcAmWG+kXAEwRfr6DCThujQU8nB+JcUANQgIrvTlnVT4ix8cgEAEmd1J5jcHAKtWSAFQTA8RtyuIB+9efTDx2n7G1KCal71oYKJVTqDDckH7wflYadt8JLcNZX//s6cppYCGNIyNa6oYqQY39sRZTKUi5qIo8cagQA6uJ1K6xYi3Xn6Y59WMZNKUcPhha8ixneHvUILchA9vfc4n4NwXS4coHAIgFoIIvqgMCY/OBzw0VcqMQ5vMtQp6k0kTLjVDFbgwQJFtuWoDrhnSh8JroTO01aoupB+1SJMnmB4iGHIDqTIgkC0KNBTZryNunqPx/HDpm8qaw74k0QSFKqgiooInxMbyQyhSCCaZ6HAHjeSy6eLL1X0wfA7IWkXXUABCkByCC1wBacX06UaQpJw/j+Y8qUVqRayHVDQCTognkIn3w2UeBgAGveo32FMKvzGr3kke+EDI1gWDCVZYII6+55zhi4bXrVDGtoFzEE36nfljn9Ra+WkF32GlKeWAalTglBLwZI3F2bUYvOm+23PE2XJgreUNyCABMkbRq2N7W5WxQyB8LAqqX2AuZH2vXmTjOIZvQ6rMMbgE7gCfeI/m2ODdTaTb9wN9i7xqhle7DZpZQ7VIMz0Di8/wBE9NsJKUUo1z3ek02jR3o1AGQTYNBMGbxAJMWkOGaztE5eotYTTK+K8fLo0xBF5jfHM8vXKO4DhkMiHg6lJtqXYGBPpjt9G3KLTv8Ao1jl/tqrWCu6DSCGLRGj1Q3HI2jmelpq/AKNVQUb9s/j0hdIJeGgLFlAaAbTI6RhQpVqqmxWpoU3WI0hdLdNQIMHrOGBQjMtVa4QqNIUgqVIYAHdoBCyCASDczJOKyhtymZOjSnwByWC3KMVYfdYQSD63GMPAKo+zh07DZOs2XZswD3jVJB+8vdoFYdQQMMJyAx0KEq5K7jk7cIqj7JxE/Dqn3T8sdb/ANnDpjQ8MHTDbZeTbjkNbJuASV/DFXT6D5Y6xxrhyrQrNAtTc/JCcckpcQUmNB+DA/uwy3mtGzIPujHXfo67PrRyL5h1AeupI6inHgH9rf4rjlWUcVXWmqPLMFHlsWMDn647Bx/OVEzFHLA6aShAFHMRafaNvTD73FXIvoaMtaTjF8Jt/RHD8/UValRSNRDusz5ocifjE48p6DuGHXnHuInF7jmQKVBq+1J9Tf5H2wNdQD4R4j0n8t/gcWi3Lg5rLOWyIqVVpUg1R3IChQDJJ/deffH0H2J7ODI5YUtWp2Opzy1QBCjkBEeu+Af0ZdihlKff1lnM1Bz/AOUp+z/WPM/DlJe8NJ9iGpO8GYzGYzCkiHNUNaxMfAH0Nj1FvYnCtS7AUASWq1GIJKHwApKwQIUACbgAAC3QQ34zGGs5llvo0puuh0KLJYtILkqyJBuYSoqNUgeUvEiIKH2m4FToVylNWNMM45EqZOgE7m2knwjcgTE4+iS0XOOK/SBUC1BpktJLGYGrU1gI5Tvc4lr6jVV3KQbZzmplyT/oNhGwxmJXrCeYxmEtlTs3ZlEos1JCWSdl0sQQPDDAxIDEEnSTzHPFzO0dNUkr5hJ5gnbUD+mA+e4An1gPlydX2oLEh9REmdhbYiIAwyZtpZVuToUm0eKPFAvE7xjj2Sakl2a/3QHaKYUHCV28SqgNbQNKtpFyCZUMKnlAmSRMnph5zk00LyBaxEG58oA3LTsIk7Y5j2r46+YQgh2C6rliFMAk1EWxMAGRsLeuC4ptVn3AylXq0auhHrX0yXJYoDo1FFUXHkA2udPwpcOp0dYp1FA1Hw1nLAgEFV0rqAbxDYmJVhO+BHdqZDNpblIt7/H+Zxpmci4uxBAEC8gDpfYbn54otqxYchLMPRD+UISPEFYlAftQST4dQJFzuMT5HiLUgxpEgsIkX5yNzbn8+eAYpMBBUc4IIMe8bT64v5LjRpgoQLHffa28frhdSFryMiROPZimzHXOsj4QZ/Kbc7XtepmOO5h2JNSNViBYQDI/Hr6dMQVlka1IEmIn526Y0oJrMHczAA3PJQMUjCCzSFos1OOV2pGmzSpEExeNon5euByDnBtjZ0K2IIgwQZBBBggg7H0xstePLbDxio/KglqkZIvptB6AczEb8/h8m6hwp6KUnZlcOgfu6hIZlNhohSUPiUbgyw3vhQfOakMgTIgx03/m82wb4L2mrqyrAa2kMQzNBXSxEnci0R6RhJqVYAdW7DcS10u6YaWpyunSRsYsZIiQefI9MNOnHNeE16lGsE7ptJdCYBprEAagIkwQw259CCOmIZAPW+0fhh9JvhmR4Ex6UxuMYcVCUOLZbXRqptrpus9JQifxxzbIdgWQkiuGkRBpxz66jjqeZ8p9j+WKFKnjW08GFjsp2NZM2jkoyhtcAEEaQYj4xhn7YZbXmKLoy+Dz32AMjlc3NrYnVSNjEiLdMRvRkQMZ/FyPp6stN3HHK++DmH0hUtHcmN1Ye/lPxwxfRP2JJ057Mrfeih/CoZ/7fn0wwN2Xp5ytQ726UQXKx5zYBT6Tc9Yjnh9CRiiltjROrI4xmnEmnGwGF3AWmQ6cYExNjBgbg9JEBXGuLDYq5xyiltJaBMDfDKROenXAK7WZh6eVqshAYDwzG8iIm3XHB+K8VZ1AOk6VIsJiTuJ2JsJHpfHRu2PF6tSlDk01a6oBuNOoAnYt1HL0kY5TxOuuowDfe5MjkPnz9sc88z+hoKgf9dPU/P8AhjMRFvb+6MZilIqdz4HxunQKnMsdUAJLLpJW0iw1Ek3YjeBeJxNxvjWrMuaYSFAgzOqNmMQALGwOy3icJ/De0NCtqDUWQlNOqalQIugAIBTAKk+KTYALzkjEuezZVazJmFA0+JF1kkwFWoUqJaSFJAAm4g3jnk3t2oLZHV7Z1BU0OwRC4jwAlAFCXBiQHBOkxHWbEBx/jFO+lkLC8KpCFiTYFWIhS7eKxIIg7YVOIOzfaJgkEAva+rVDWEyfcgnEWXbTcqxMNzBEx4TpKmQDv1sQRGNGCWRaLXF8zSrNqQMKjH7TysWIXUwBGna8zAMmTEWY4e1B1LyVZVYMFswZeQPQ6hfeJ54sZDiFFQA1HUpJlCzaRuFaQdVgx/uruTONRnAAoAA/Z7kQPKbRzOqR+NuTyYSIcQqx5RG2xt+PTHjQfMBq9I57Qb+0Yu1OKRoIaS0azoC6DJlZiGtBF+Rm5tHlKQzDlmrhROkKZBI0k6o2gab352wij7IYo0TBPg1RvIO3w5zGD/D6mnXTE0HdYICh/AVkTYQb7CCJ5c5OGVKC00JaqHBkssERyEAgg+U6rgRte19M/lnXuSqMxY3WmoLARBkASethMCIwkpXwBC1xPg3dTLg+viueZMifh+cxifJ9l8xVBajQqVEmAxUU9XqFZpI9if3NOS7NCqTqqlb+UN3pjaCCFKj0BMfHDnwzLPRpokToUAFppzAsS3itHtiM/VbaSyzcnMqb1Qy5XMUApLgEPKyJGkA8lHi8vXB3iXZTK6RUyjmnUEXLNpurGbgsOQmBytJnBzPcYzZZ/q2WXWD4ajNTYETcKNWr8v3hc7Uz6jVmKLeJTLLTPQ2lPECesiOgMHGWpNy8e1gyHeD161Jqaq5dFaHpmCYGpRpBYSvhVhABld9xjoNJ9Sg7T7j8744XwnPEMO8D91qBA1ItQuPEhk+ISwAJXkY6DHaeFDTRpjfwi42PMGTG4vjt0006YLLwxhONA2MnFgmuYNj7Yp08Wa58JxWpXGBQCWMejGY1Np9j+WGQGWuF5habS2xWOvT44Y8Jat4V/qj8hhypmw9sCQ8GbY8x7jMKOeHHkY9OK+azaUxqdgo6n2n8sFCssY0qVABgbV45RAs+ozGlbsWjVpjrHX16YSu3XatdH+71D3i8g0CCdLSJ5REEcwQcZtLLEc32Je2XZxKlOrmWqhjpbRZFFxaXIMwsm/OIK8uU53grrV7rVTaLFlYFBIlSXG3x6HDHW+kVmorTZKZUAh1uupdLDSTJIN5FibTBxVzCn/eKpUIpCrPUlTKBvtHaZJmTO5mOtqqrjyIr7iLVQAncelv34zEZp+x9Yn8cZie+RQNPXSmyihWciVZ9xM6tX2hEqdLcjIuLgT8Qz1SogNKAisYJKQTYDS0KYYBiQyjw6RcWwEy/EogOiknSBUM+BZ8fgnS/MiYggQRi9wyjJiij1ACSVZYBBGhWYAsgALPzkT5ulGlV0ErfWhUsVRCQq2UQYtJ8XmPoN/jMGYyzjUunSJuL8pEHnb1w1cQyyUKSOlNVqAAuSlNwTzZWkqy+IDwgQCJ1GTgJn88tSfANcrDKQAIBGwHO3OBHOZxKL9sBtcHnDckKhjuk1DxFrgWPkCkwZAgCCZj1xrV4egR3nxK0FfDsTbQNXjHmuNoFtsVcpWYRpMEyIJF48U322Eeu18QVsxY6idWw5CdUgzNrEiw2AHXBadgYRyvEqdNCFDkGN1AEiY2PqefPA/NUCo1eUPMKIsAYNhtccxj3uBeWLKCBqA+zqjUAfawnFzjFPKqf2NR6hOolmO3iYKI0i5GltzvG4OMlXBm8FTLcRZAQsR1KoW6+Ypq+RGCOXzVd2B01ZEQF1FQQZnQCANp2wHQry81+Xy9OuGjhj11pqJZlWxUkwOcehFsJN1wjRyXVq1ALszMQZmIE8up5D574t5Pg5qCakgODAnla5+dx6DADOZ2q1QjTGkp4bXkCfhf9MNmTzwVSCfKPlzP+mOHW6mnH4e/gEscBbgwQqF8u4UrYqVaCI6SLjbntgVnO0FXLVe5roHH3xUA1LyMMd+RvyOAmW4rXoVJrhBTYkq6mftTG94B5fra12oFPN0FqJUGtNiCL28hPLlbkThVpJTqaw+4GkmBuJVaArrVyvg8eogtKh99QuRv0MXtscM9PtPmxRBSvZCVYzTc/Z03i43M+scsIfDEkXWfW+CH1Vfun5n449NPbST4KxjF5GpO2+c/6w/uUzz9v5/DEy9us5zemR/UHX0/mL4T/AKqvQ/M48OVH9LFOr7j7YeBtq9uc4wIPdlSIvTuQRcfpgNQ4vXE6arqOgJMW5ew/LAavQVQT4ufTpin9dpdX58h7j5nDqTfAKih0p9pc0P8AnN+HUW/naemCvBO0WZqV6dN3lGaCCLkQf4fEY5v9eTk7elj0n87YM9kM8pzuXHeEzUAjxfdP+mHTYstozVu1eZBKyCASByiDAuP5vhk4T9JNRbVF1AWlhEf2lG52jRvjk+bzBR2BqbMevWP0jEQ4k1oqDl0Nz7j5+w6DDqSayCl2Pozh3bfKVPMxpn+lBHWSykgD1aMMOWzKVBqRlZeqkEfMY+Uxn3BkVBPWRO59Opx1f6H+B13b67VqTTGpUpgsPGDpLMLAwuoDffAajVox0DjvHKVE92+sF1OkqNzsACftSR8/QxyHjXbhjqEVCS0928gRO3mk3ttuOc2bPpKrB3lHdmphlKooBRtO4qEEyS6CLCJvuCgZKgncmwALGAxVi1RQpqKIA5r5SQBqWbwTzyqVpvCJSeSvn+1hJBl6jNeoTuDYQu8mJFxFhbF1uE94e+aKfglvGoQMVJFNSxvHgJIlZ6eUA6ORpvT1kU6akwpVi1V2LNPg1iBCxJVV2jcnGZls4CaeisypcCGLzHm0iJYQt7gFTG5OIvTjeDBXJZQpVWgadmBZ+8QjYTqFoZTYc9owJ7X5qABTnTJgyYIgWHKL/wA8puDcSC3liwRkOuYjwlSJNidJkdb9MDu0WZDJSIaVRdNg1/E22rYQfbfEVF9ZexlyBNa8wZ5/zOMxbytahpGoPPOHgb/1Dy9ce47sByVa+W0kgHWAqksAYAdVInpdgvuIwa4Dm2ouHpsASCGBKkm26swOkmDtBPqMOGT7M06T5tDoanAQS3eOjCn3it90y5bpEzeSCu8N4aFr6GghoIJmQQDYEWJg3Ftx6SNRYwxrKOb4sGcSo7swugalGkeHSLkAwZ1RvfFIoGKhYaYCwdPML4hHQDrb1w0cW7MAgtREuWkhibywkzNoE8jufTFrhXAqlNw7MJI8dgbmSwBifNeZHLeMLQATluBR4mmenS/xxJ2fyCUa7VKxQIAQAwBBmNKwbE2nbkdsNVTLDFOlwUV2ILEBShYcmEmRPIxseuA4WgsXOOZagFqkAhmAZFMQJZSzzMix2IEz6YDZrKq6q9IHSEBcFhapJDRYeGNB+Jvyw59rOCNTyulHZl0kOCTJ06WBEWAApsxty5YI9muJUdbqSoepTWsQFgQEAeYkCLSJ64KjWAJCJ2X4KMy5Ul12gqAQBIDST/WUWBjUCbY6aOzyBCiz5tVySZtF94tt8MX+G04QEiGbxt6FvEVnnE6R6AYurhtnkJyHh3Cq9fMPRRmDKoYlpAAsBcT9l5HUAwdpPcW7OtQoPUatULEeFEUxruYa5lQPQRe5sMHOD0QOJ5pgYmkkra51FZHoBTAtO+/LDO6A7if9I/U4DjkyRwX6vVq1Sps5a6xBBvMIBNucDpjK+RZH7thJIHWDIlQLT6bb4YO0vAq9J3qKjwwZ6hFls0FheSJY8hYg3m1BKlVAtSCwLI+1Rlchgwpk7Eqxgjrbe+AA34LliC2ohdB0spBDybRFrgi+q2+2Ok0OFU3EgA8j6Ebg9CMJmQytQMA9MKWadlaTMgh7kFZI07nV4rY6ZlcqlMQihfQCBYRsMK0mxkBm4Cn3RiNuAU/ujDFjw4PTQ1ilxDs7T7t/D9hv8JwkDs2DyPzOOvZlZRvVT+WAFLJYVpx4Mc+bsyOh+eCXZXgOjOUHv4agP82w5NksSZPLaXVo2M4KlK8szo5t2hyBAqVDbxfC7/xwDyeXqVTppIWPOBsNySeQgH5Y6Zx7IJUy76vKQGsY2cNv0tf0mMBchmqNFH092us6qVNZqQBpgMSPvC83+BwY6jiuBJM1XsuuVRKtXxPIYEx3RGnUAImTG8kG1gL4bMp2iPdqtJmfSZGgKNJMB6gVGaUuNMMTqIECxwNzSd6nd5ircGGkSVkiFAA8MTNpgTa2AlR0VhpNPUiD7AWGncNE6hJk6jz2gzHqSbbYgfzNA1BrR0CVGvrpvq1op7zTPiZmkm0yBuNgtZnuipUVe9qOdP8AwyiUU1BmABmCX0yRaARzOJsxlypR1roxkBD4pLMfMmoCbrJaAbE3wz0+EZddNAolSoYmq9U+IxqcBQFKwV0gxMEEzBGEepGGX3MJA7pHR0q68wWE04kXsBNhqmLcrcwcEk42lWnSpGuqDQe80B11sSNIIVYkwpNtJAiSYAJZzJ1VApUKeXpq5AFYHTIMEODOpSLEwWjTznAbNdkadOlUL5iKq3CBVCuY8slrybBgee2GWvpvnn7mRdyboraFDOpnVUFM61U+FnRQJkCIWTG94GM4hwgvSWkiL+zaIgtUC6Y7xrDSvOIkzYWwBb6whAAejIWBTOiVkhm8N92kkyb/ACtccXTSYLW1GwafO+pQH3PiuWUm/v4sO2lJB7i3V8DFJPhMbgfgdjjMRNmpMlQxO5MyfxxmL0MdGo5tnXvdCMxEFxpOhTBi0XYiwYTYmZxdWmrASNtrbYScvUdGDIYjkQrD5MCJ9d98GOG8eCkis5NhFh+gGIaO35QuLGyliXAJe0WX+/8Ahjb/APJMv98n4HHUAL1WtiXghu59R+uAVTtFQP2/+0/uwV7NZtaiOyGRrjYi+kdffGowdqorqVYAqwIIOxBEEH4HC9w7gqeLvB+2ptTy/eGYq5crUcW2LMtNUYm/gMb4Oh8WFqDumtc1aY/7KxH5NgmRsDjdTiuHxt3gFztzxggfhK68/m6smKa06IvYmNTz6gwPnhiBwsdiH1UKla8161SpfoWgD2GnDCK6nZ0Ps6n8jgVYSZ0BBBEggg+x3GKlDhdFENMIChjwm4sBBvzsL72xMtUdRjcHCuJiKlkqagaUUBWLC1lYzJHTc4saT0PyxLlKh+r5sgHUqgpa8jV5efTbCPSbNQp73MeFlnwVj5Qe8IlIOqRFvbCt0+CunpbkOehuh+WNSD0Pywm682As1qliC37OL6iahum2kiAbTPTA8cbzEMTmxyOyDxaxG67aBPIcvQrv9in+P7/wP1awM9DinTFp5YU6fH8ySwXModgv/DEsWGkWv5QTbE1bi2ZLs4zAIGpgNSw2kgU5gjzRFomMLKeQr0zGcsOh+WPaQMiw+J/dOF1+0WbuFqUjJaG1HYABI8exaRiTg3HM01ZFZ1Kux1CCSF8tvF96RzxlKxZenaLOZyIqZbu3MgooMW2jn8MJOdZaJemEUhWYFihDSFDJ4lAkjUTMmJ5AAYaV7RZkAjRTK6Sq+E+GEOnckXYqDaLY0zHGq0sTlsswKkS1MEiE1E+ksdN52GF3WB+mbViVTqMUhFAUDWQGXzQSzdfKpJVZ2EjbFqlxOiaIFV3dy99WpvBPo0qQVDXnUSBYAkvvafgmTXI0c01IUSWCOKKIANRaR5bXHmA1cpvhL49SpVRoooqGmfKFEqsydR+0QI3uTM4E5RtJo55KmWeAZHvWSEaFYNqK+YC2p0JZRIj729pjB/N5xBRMMgL+ImDdTJOpVB8fhAvIPXkAfCMpW1PVhnIA7tVUMqgkQ4a6qRsN4k22xLX4e2nVmGas8LraH7sTzBEMSFiSFtFzjk1I7p9iTJa3H9ACMQyiyAqVJA/oqAF9IvblN8yXEULroXVBBWGZoOrprNyNoG4O18COJZSrW/a0abKI0nzMWMXAMBidvYG8TjMhTpqlRnvJsUV1eSYYLMAbkCyj1OwPRjVgotcYoUGrPVqEghSWpBV1gCWJOgwxNgzNBAjqIWszmRmWexGkEqVURHOegJCwI53jDVw/hNF11Vzo1SURmdAoNoIHhUAECTPKSBhVNFaeZqUQCEJIQyHkboQRuCI52m98X09vCy0MmDFyRa4Vo5eFj+IGPcTVCgMaoi11AMCwscZjqGL+mNo+X8cUs43jv0H78Vvrr9fwGDA7rMDTTp/tbRDEBpAEETNjznn8paem08lmwUGxtOCWVyDEgGhT6Xq1BP8A9v5YspkGJ8OUD32WuwiDceJjvbFq9zKS7gimf5IGLmWztVBFOs6DorECeZtblhj4dwjLPTLVKbUiraGHfEwQPFeD7fPEeb4PlRp0Mw1sU1d8CF8JYSDS6gDf7QxqaNvgwOnF81/6ir/eJ+Nxg/S4tmP9mVH759f1xFDWkDuKhgWvv+OAvHOC9xRFVaodWMAyCNwPu7TP4YqUuK0zku4P/FOaFXVAjuhQZCJ66jMHBtmuJa/2/nN/rD/JP8mMr9oM2QVOYchgRGmmJB32SduhwB+ssTy+QxvlsyQTCK9tmBNutiMC2ZuPYYeHcbzSCnTWswQQoXRTgCdp7udvWcMFDKCDMteb3j0HphFyWYbvaQIW7Ly5ahjoNOk9yHEdNP474pBWS1KxRVq5On96OXmH64loZBDcMT7H92JDliTOpf7qz88TUqDCQCoHoOdpNvj88U2ryTtkHE8ohpaSLM9MH21jFVOz1H+l8Af34I5tWCpqIM1qew/pE4KotP0+f8cOsIDbFt+GJSqUGTWD3yAyxuDfFL/adQAD9kYCfYbYHc+LmTPLB/jQUHLx/wBdP1wiJ2mzWkCKV1Vduja+TdTjn9Qt1HX6TU2XbDq8RY6lIokExdWGzXiW3Mn4YgGf03HcEkPcDaWBnzbmLfHAhe0WYA8lM78j9ppJ825ONanH8wZ8CXDCwP2vN9r0xyqD8HY/UQ8/gN/WU8S/7vAVwL8yQReeWwwS4PXQ5mmAtGRWFwRO67D0jCs/H8wQf2NO9/K3MADn0GL3ZzitSpncuGpUxNVLw1gBp68hf3Aw8UyUtWFOmXM46l3XRSPjYGWEwFkza23zxTpqhYeCn4iLa+WjmYtcTiPiXH3p16gNGmQlVokG+ksBPvOrBfhVYPQoVBQoTpuW1TK1aiiIYfdnb8sZRbM9aCSz+BwyLI/AiHURT0sRMxDLLT1szbel8JeZztHvitBbapqkIagTSPA4CAgKJIMSPbBzJdpKdKhWyr5dRTdSIpiqQS0ydRfw+bcT+GA6VaUh1y9RWMeJMyQd1idVEk+Vd72wXo27Zxzak7TLtXijUxU16qSlkFN7DUvMIhgloMGCJmRG2AXabOMtSoKdV7WIQtdTD+JgxAAcgaRaQemLHaFMocxRK1ZJdkdalQt3ZmBJGyhgQAABYTGNu0bpSp0/2KlVusvUZASIqeGReym4gzJNxiC0lCWFkm0CeGCsX8FTz7zUV9I0SzEh18YECLbwemPG47UUlKq3sWXSiOQSCRqABX2E2AsItV+tNUJp5cGWdW8OlWaV8ak7mGE6QCBc9MeZvh1ZkZmqjuqbECTLCZkCwDREWJ9OmLbVeQ0u5eyOcp1rNT0kL4dGkgwbLBBsCSbeKABNsElzFOpprFzrpo0KxDKZBmdyrMReTsx2vCXQ1gWO403G88hPuR7E8pw65OjTp1GyhbwLTBqVAWaXZVJNO1lBZRECQCdwJjrRpWgUJWbu7EyTO+PcXc9xBWqMSpJJJJBAHyjGYqnKhsg10tgx2aVUrBnkrHub7W+GBlKoGsJw09i6M1SSLBST8iP1w6tFJF+uUVSdWqAPsjyx6Te4v79DjenXKMDq0gmfttFgPKBHLYxi4CC5AbwkxEmPWbdQIPqb4IcOSmTu7EX3Mb+lrwLGcI2nkTjAP4NnKfduAxVmdm8pO5ncAjpjbN8RHeUx3gbTJJ0t4ZUj/p33ODHZ3KE5OmSSskkxq/pATpIIFwd/4b5hIsKjCeWisTAAAFnmb/H4YpGNoRySYs9q81RrU0RW1kXaVK8xFoHQ/LChmcoiwQo326jD52wVopKYJhiSBHMRYz064UeI5QlJ2K3/AH4Er3FI1tB1HKo7wiwoHi3v6fz64I0Mgi3VYnG/Ccue71RYk3+Mb/DF0Jicr4KIprkk1K+m6EFd7QZHPrg3T4m5MaRimFxLQTxDAUpLhjNRZO3EyLGmhsPxGNTxiL92LcwYPzjFeoPyH5DELLhnqTvkVQjXBY4lxsuiqVI8QYFXAII2uUPXFN81rDMamY8CM0Cuo2E8qfpvipnjAWf5tjTK1Rprf/BU/wAOGjqz4sVwiaHtK0o7LVbSwYBqyRqG0xQBj44XVkCJ2xJUcaQIMzMzb5Rb8ce4u5N8ipJEZY9cbdy2nVIjpN/ljHGNyo0+a/v8h+eFeBkrGJsWuy3/AJ7L/wDyL+eBy1gQIOCPZf8A89lv/mX/ABDHNBfEF8EfafK6qtccxUqEe+powT4LlP8Ac6KsjHwvcIXAPfVYuARPi2OPOPJGZrj/AN1/8Zxdo1glPLglQNFUwWALHvoULO7XNsVg9qbYks0kDczlYN/XdAP1GKyqg8zr0AmI+Gozvtil2q4jXp5ghMxUClQwCVWAvNrGJtirl+0Oa2+sVCbX1knFFJNWJsYVOTWpmc2juUXvakrT89QrUZkJWCGg8gJ+WKnahAGMFwSokNYwNtSAAC2i14IPsI+P5p6OdzOhipFdzqG8h2i+/M+9p2GKI4nU197qbWIho52Em15A+POb4k4vdZqPcqNGvUzIbKadOQaiwdYL7KumQd51RGLmV4popvqKlWRqYBkaiPHshDJLMBYgHU0m1h9elUqaqml3IGp2gmP6Rj7IEeI4gyFFXdQwYrP2QSepA+E4bkNFzP5+kygpSCMW1HxEwRsFEABfQzsIO83+H5xqaiBLs0mbKRIsYvzIiCRA9sa8Y4Mq0hVSlXA0+bQdE85JH8LYt9kwBTLMoJUswP3VAEHa/iJ9gDPKJ6lKNs2OwGzOSqa2lIMmRAEHmIMR8se4t1suarF2ptJ/9yNrbR6YzDKqMZlOzWeUF/qWY0xuaNQC299PpifJ082sFMtWBJII0PtH2vBi3l+I1mpBquZqFbwveMzCIglPsqZ8J5wel7dHNtUXWcxVO/mYmI3G5/DFdgktSS7GvBlrs/7WhWWmDLgLDMARYawogjnPww2DtnkMv+zGSdLAxpQ2Ikf807gzhcr58U8sC9Soe+Iv5nCRyDEDy9SPMOmBrcQyPdGkiVJO1VsvS7ySZ8wzJG9ttsSjGM7u0u1CwctS3/DOj5DtxkwgBoiiv2VdEEjqACRE43bt5kJn6uhPXTQ/VhjlXGKw1qpMaUUfgP1OPMvxBUAHd0mjm4LH5BoPyw8dO42r+40YJq8/c6fmu3fDT4nyeqP6GXJ/CpOB+Y7b8GcENkHgiDFNB+VUY57nswHhtKpAiKYgH1Nze+/tio0RM3w/SX/Mfb7sc+P5yiFU5NKuXpkGKdRFZWMydJLMb6puY+eBNGvWCn/d3qQQNSq8NNwVC0yNIHP94wQLrUyVPUNWkkC/Xb8F/HA3hPFWCpS7+orGwUFoH3Rva0YhprdYi9RPbXNMtrUzGkscnWUBgpBSrN9j/wAPb19PbEtGvUDkHLuNJAJh4vzB0XHU43fNVV82aZfdyPzbEjV6wicy4m13I/M4r00b/Im/0rP1KNatUAYdxUOnSJ0teRuBpuPbpiJ3qyR9XqWIHlbc+unb1wSq5isBq+sVYiR4mk/CcbfWqwTvDmagWJks23zxnpqwL1E6+VfkWOK5Wu4hcvWkHlTcz/2404NwjM/tpy9YTl6gE0qgknTAHhucN2Xz1UqWGZqECbhm5b4IZLj2aIIXN1rGILG3TngqNG67fKOfr2WzjKFGXqai1gRGwJ3JAG382xTHB8z/AOnrf/qqf5cdPyfanM1dQTOVSUMHce2++xxlHtfmmdqa5qrqTcEflIv/ABGCHqnNcrwyqrqXy1VlBupp1IPvpg+sA4fct2sq0qRoU6WVFE7p9VOk+6zf4zi4nbPNtUakuacsu4gfnGPcuzMsuZYsxJ2klje2OP1cnGKkjp9NrLc4tCNnf2lQsmXWmo37pKioT6KzEL7CPbFvsxSb69lfCZ75DsdgwJPwAJw40+0dXKr4cx3as0AQCJnkCDgjR7T592CrmCSZgaad4Usfs9ATi8I4TIT1028CZ2mUjPV6YDM5qsdKoxPiYlRAEmREdcRcVSqoyjI5oui1vE4KlT3pBBUidp5YcW7YZ4AE5mByJWnHp9nEdftlmwpL10jbxU6UX/sYeqWBOomc3zvCa9ZpFalXY8lq+I+yuEJ9lBwJr5tkikwCFDdSqg6gYMyJm0b8sdNz/aCqBqqGkBtJpUgP8ONqfa6vTW/c6RzelTMfGMaNrn+BVq9mhD7WVh9bzNyCarQdQAHiMiIvPvbA/JZSu4JRKlQD7oLet4B5A46dW7Y14JNLKMDck0FIOKWc7SNVXS2XyUC4/wB3UQeovv8AhhrQ3UQnUBrWIJnluY6YDsoCsjA6g38MM9esdZcKqtMyg035m0YDcXonWKjSdXmJJJMepvt+WJpUNGdy4JqaKFHgOwGw/PFvKVWoUK7J5aoWnF9tas22wMRfe4nFXjFMU0BS0mNz0P7sRZqrqpIkCeW0/P2v8sSjLdG35KTik8E9btFVBhWgCI0lgIi0DkPTGYCMo9ce4bYgDBmmVcuYAGoDYRvi1wGjNNF5EEk+hJJ/DFPiVFmphVE7YNcEzyZampelTqMVC6amqBaW8rC8wJxfUe1Wc8vlK+eyGYztYpl6es0wPCCqxO12IGwGKWd7L5rLshzFLQGYAeJGuf6rH54aKPa5F8mWoqPRq3x/5uNq/bNWHiy9Fv63et+dTE4akIx20NGcYxUUIXEqmqq59Y/QYi1Ef646LT7VLAIpZYQLL30EACwCd/M+kTizS+kBl2pUvk5/N8Pvilwyi1ElWTmpe0WGNO7H3l+eOrL9KlRRASkPgf8ANiCp9J1Vvs0j/ZP+bB68O9m6kRa4XegEmbiOfr+uAlbKVEzCiNLarTtY/LbDPn+2LVJJpZfUSCW7oa+k6jfYYqZrMmtWRgAAh+fhYfqPliWn87rgisNsNZLKd4jG5g7BtO/P+emK1JgASWI6QxUTykjly9zihVqV1I7p2Uc4dl3N9t7RiLiuXdwoQwLzeJFrevPFnB/EOp1tzwWc+z9yuhobSt79OfQHaT1vj3LU2GW0NCtBmNMKdROy+GB0FoxBxTKmpRVBE+HnGw9sSZGmVoqhFwIIBjncTG0emH25/YRPC+pvwWg4paKinWSZAsSWA9PMZ6bzgrlHkn+iqryi0i0ACPYYG0TV0Nqb9p4oYWj7pHTl6++J+Fo6r421MdyBHUxA6TH7sKou0aTVS+ppwDLoj1QhJHhJJ3k6iRuRaQLR7b4i4QP29aaYXxvBlbjWBOkANcydRnpyxfySVA7M5UkqglRp8qxt+v5bYq5DIVUr1KjspVp0gTIl5uI3jngpPBnXxFDIKBn6vUz+QwzZfb4n88CMvwxlzL1iRpaYF5uB+owSpPv7nHD65PpfuX9PXU/YDdo1OmnHOoZ9uc+mGLgQjM5YAeYsP/oqH4bYF5rIitpBbQA8kxNrz/NsMHZmrRp1qdSsWApgkaRMsUKQfSHY+4GOvTWL9kRdbl9WLfEcvNFVAJJKgAbknwx6ebFLtT4cu/OCPzj9cGs/ly6lUYLexabCfTnGIeNZHv1dA2gMQdWmYAYHb4YdrAi7fUF9r0nLt7r/AIh+/BLhvtL/AV/ZpnKCOWXUioS0EtCgMa/"
           src="https://i.ibb.co.com/gZLRg0ZP/Whats-App-Image-2026-04-08-at-15-06-15-1.jpg" alt="Whats-App-Image-2026-04-08-at-15-06-1"

          
          alt="Gedung Kelurahan"
        
          className="w-full h-[250px] sm:h-[350px] md:h-[400px] object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-black/60 flex flex-col items-center justify-center text-white p-4 sm:p-8 md:p-12">
          <div className="text-center">
            <motion.h2
              className="text-2xl sm:text-3xl md:text-4xl mb-2 min-h-[2rem] sm:min-h-[3rem]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              {displayedText1}
              {showCursor1 && (
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.7, repeat: Infinity, repeatType: "reverse" }}
                >
                  |
                </motion.span>
              )}
            </motion.h2>
            <motion.h1
              className="text-3xl sm:text-4xl md:text-5xl mb-4 sm:mb-6 min-h-[3rem] sm:min-h-[4rem]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 1.5 }}
            >
              {displayedText2}
              {showCursor2 && (
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.7, repeat: Infinity, repeatType: "reverse" }}
                >
                  |
                </motion.span>
              )}
            </motion.h1>
          </div>
          <motion.p
            className="text-sm sm:text-lg md:text-xl max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 3.5 }}
          >
            Melayani masyarakat dengan sepenuh hati untuk
            menciptakan lingkungan yang baik
          </motion.p>
        </div>
      </motion.div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          className="bg-white rounded-lg shadow-md p-6 border-2 border-[#D4A574]"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 4.8 }}
          whileHover={{ scale: 1.05, borderColor: "#8B6F47" }}
        >
          <div className="flex items-center gap-3 mb-4">
            <motion.div
              className="bg-[#8B6F47] text-white p-3 rounded-lg"
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
            >
              <MapPin size={24} />
            </motion.div>
            <h3 className="text-[#3E2F1F]">Lokasi</h3>
          </div>
          <p className="text-[#5A4A3A]">
            Jl. Palem No. 17 A, Cipete Selatan, Cilandak, RT.12/RW.3, Cipete Sel., Kec. Cilandak, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12410
          </p>
        </motion.div>

        <motion.div
          className="bg-white rounded-lg shadow-md p-6 border-2 border-[#D4A574]"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 5.0 }}
          whileHover={{ scale: 1.05, borderColor: "#8B6F47" }}
        >
          <div className="flex items-center gap-3 mb-4">
            <motion.div
              className="bg-[#8B6F47] text-white p-3 rounded-lg"
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
            >
              <Users size={24} />
            </motion.div>
            <h3 className="text-[#3E2F1F]">
              Layanan Masyarakat
            </h3>
          </div>
          <p className="text-[#5A4A3A]">
            Melayani Administrasi Dukcapil dan PTSP (Pelayanan Terpadu Satu Pintu)
          </p>
        </motion.div>

        <motion.div
          className="bg-white rounded-lg shadow-md p-6 border-2 border-[#D4A574]"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 5.2 }}
          whileHover={{ scale: 1.05, borderColor: "#8B6F47" }}
        >
          <div className="flex items-center gap-3 mb-4">
            <motion.div
              className="bg-[#8B6F47] text-white p-3 rounded-lg"
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
            >
              <Building size={24} />
            </motion.div>
            <h3 className="text-[#3E2F1F]">Jam Operasional</h3>
          </div>
          <p className="text-[#5A4A3A]">
            Senin - Jumat: 08.00 - 16.00 WIB
            <br />
            Sabtu - Minggu: Tutup
          </p>
        </motion.div>
      </div>

      {/* About Section */}
      <motion.div
        className="bg-white rounded-lg shadow-md p-8 border-l-4 border-[#8B6F47]"
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.1, delay: 1.4 }}
        whileHover={{ borderLeftWidth: 8, boxShadow: "0 10px 30px rgba(0,0,0,0.15)" }}
      >
        <motion.h3
          className="mb-4 text-[#3E2F1F]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 5.6 }}
        >
          Tentang Kami
        </motion.h3>
        <motion.p
          className="text-[#5A4A3A] leading-relaxed"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.1, delay: 1.8 }}
        >
          Kelurahan Cipete Selatan merupakan salah satu
          kelurahan di wilayah Kecamatan Cilandak, Kota
          Administrasi Jakarta Selatan. Kami berkomitmen untuk
          memberikan pelayanan terbaik kepada seluruh warga
          dalam berbagai urusan administrasi dan pembangunan
          masyarakat yang lebih sejahtera.
        </motion.p>
      </motion.div>
    </div>
  );
}