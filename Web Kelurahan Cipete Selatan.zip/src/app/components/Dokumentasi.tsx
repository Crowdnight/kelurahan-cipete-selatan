import { useState, useEffect } from "react";
import {
  Upload,
  Calendar,
  FileText,
  X,
  Trash2,
  Camera,
} from "lucide-react";

interface Documentation {
  id: string;
  title: string;
  description: string;
  date: string;
  imageUrl: string;
}

const STORAGE_KEY = "kelurahan_dokumentasi";

const defaultDocs: Documentation[] = [
  {
    id: "1",
    title: "Kerja Bakti Bersama",
    description:
      "Kegiatan kerja bakti membersihkan lingkungan RT 05 yang diikuti oleh warga dari berbagai usia.",
    date: "2026-03-26",
    imageUrl:
     "https://i.ibb.co.com/Q3RtRFsr/Whats-App-Image-2026-04-09-at-08-30-38.jpg",
  },
  {
    id: "2",
    title: "Posyandu Balita",
    description:
      "Pemeriksaan kesehatan dan imunisasi rutin balita di Posyandu Melati yang diadakan setiap hari Rabu.",
    date: "2026-03-28",
    imageUrl:
    "https://i.ibb.co.com/Nd56rZLz/Whats-App-Image-2026-04-09-at-08-27-42.jpg",
  },
  {
    id: "3",
    title: "Giat PSN di Jalan YDPP RT006/RW01 Cipete Selatan.",
    description:
        "PSN ini bertujuan untuk mensosialisasi bahaya jentik maupun penyakit demam berdarah serta juga cara pencegahannya sekaligus silaturahmi para kader jumantik dengan pemangku wilayah, menggerakkan warga untuk selalu hidup bersih dan sehat",
      date: "2025-11-28",
    imageUrl:
      "https://i.ibb.co.com/GvQZZ7PY/Whats-App-Image-2026-04-09-at-08-32-22.jpg",
  },
  {
    id: "4",
    title: "Apel Siaga Pengamanan Malam Takbiran",
    description:
      "Apel ini dihadiri oleh unsur Babinsa, Bhabinkamtibmas, FKDM, Satlinmas, serta Pokdar Kamtibmas Ring 46, sebagai bentuk kesiapsiagaan bersama dalam menjaga keamanan dan ketertiban wilayah menjelang perayaan idul fitri agar tetap aman, tertib, dan kondusif",
    date: "2026-03-20",
    imageUrl:
      "https://i.ibb.co.com/7J84n87C/Whats-App-Image-2026-04-09-at-08-34-59.jpg",
  },
  {
    id: "5",
    title: "Penimbangan Bank Sampah & Sosialisasi e-Bank Sampah",
    description:
      "pada kegiatan penimbangan Bank Sampah yang digelar hari ini, para warga selaku nasabah aktif membawa sampah terpilah dari rumah masing-masing. Mulai dari kertas, plastik, kardus hingga logam, semuanya ditimbang dan dicatat sebagai tabungan",
    date: "2025-12-02",
    imageUrl:
      "https://i.ibb.co.com/27MsGr7B/Whats-App-Image-2026-04-09-at-08-37-30.jpg",
  },
  {
    id: "6",
    title: "Selamat dan Sukses RW 06 Kelurahan Cipete Selatan!",
    description:
      " berhasil meraih Juara 1 Lomba Kampung Bebas Jentik tingkat Kecamatan Cilandak. Terima kasih atas kerja keras seluruh warga, kader jumantik, RT/RW, Puskesmas Pembantu Kelurahan Cipete Selatan, serta dukungan semua pihak dalam mewujudkan lingkungan yang sehat dan bebas DBD",
    date: "2025-12-02",
    imageUrl:
      "https://i.ibb.co.com/kVWW9sX8/Whats-App-Image-2026-04-09-at-08-38-44.jpg",
  },
];

export function Dokumentasi() {
  const [docs, setDocs] = useState<Documentation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return defaultDocs;
      }
    }
    return defaultDocs;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
  }, [docs]);

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    date: "",
  });
  const [previewImage, setPreviewImage] = useState<
    string | null
  >(null);

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      formData.title &&
      formData.description &&
      formData.date &&
      previewImage
    ) {
      const newDoc: Documentation = {
        id: Date.now().toString(),
        title: formData.title,
        description: formData.description,
        date: formData.date,
        imageUrl: previewImage,
      };
      setDocs([newDoc, ...docs]);
      setFormData({ title: "", description: "", date: "" });
      setPreviewImage(null);
      setShowForm(false);
    }
  };

  const handleDelete = (id: string) => {
    if (
      window.confirm(
        "Apakah Anda yakin ingin menghapus dokumentasi ini?",
      )
    ) {
      setDocs(docs.filter((doc) => doc.id !== id));
    }
  };

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="flex justify-between items-start gap-2">
        <h2 className="text-xl sm:text-2xl md:text-3xl text-[#3E2F1F]">
          Dokumentasi Kegiatan
        </h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-[#8B6F47] text-white p-3 rounded-full hover:bg-[#6B5744] transition-all shadow-lg hover:shadow-xl"
          title="Upload Dokumentasi"
        >
          <Camera size={24} />
        </button>
      </div>

      {/* Upload Form */}
      {showForm && (
        <div className="bg-white rounded-lg shadow-lg p-8 border-2 border-[#D4A574]">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl text-[#3E2F1F]">
              Upload Dokumentasi Baru
            </h3>
            <button
              onClick={() => setShowForm(false)}
              className="text-[#5A4A3A] hover:text-[#3E2F1F]"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block mb-2 text-[#3E2F1F]">
                Judul Kegiatan
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    title: e.target.value,
                  })
                }
                className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] bg-white text-[#3E2F1F]"
                placeholder="Contoh: Kerja Bakti Bersama"
                required
              />
            </div>

            <div>
              <label className="block mb-2 text-[#3E2F1F]">
                Tanggal Kegiatan
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    date: e.target.value,
                  })
                }
                className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] bg-white text-[#3E2F1F]"
                required
              />
            </div>

            <div>
              <label className="block mb-2 text-[#3E2F1F]">
                Deskripsi Kegiatan
              </label>
              <textarea
                value={formData.description}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    description: e.target.value,
                  })
                }
                className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] bg-white text-[#3E2F1F] min-h-[100px]"
                placeholder="Jelaskan detail kegiatan yang dilaksanakan..."
                required
              />
            </div>

            <div>
              <label className="block mb-2 text-[#3E2F1F]">
                Upload Foto
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] bg-white text-[#3E2F1F]"
                required
              />
              {previewImage && (
                <div className="mt-4">
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-full max-w-md h-auto rounded-lg border-2 border-[#D4A574]"
                  />
                </div>
              )}
            </div>

            <button
              type="submit"
              className="bg-[#8B6F47] text-white px-8 py-3 rounded-lg hover:bg-[#6B5744] transition-colors"
            >
              Simpan Dokumentasi
            </button>
          </form>
        </div>
      )}

      {/* Documentation Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 md:gap-6">
        {docs.map((doc) => (
          <div
            key={doc.id}
            className="bg-white rounded-lg shadow-lg overflow-hidden border-2 border-[#D4A574] hover:shadow-xl transition-shadow"
          >
            <img
              src={doc.imageUrl}
              alt={doc.title}
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-[#8B6F47]">
                  <Calendar size={18} />
                  <span className="text-sm">
                    {new Date(doc.date).toLocaleDateString(
                      "id-ID",
                      {
                        day: "numeric",
                        month: "long",
                        year: "numeric",
                      },
                    )}
                  </span>
                </div>
                <button
                  onClick={() => handleDelete(doc.id)}
                  className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors"
                  title="Hapus dokumentasi"
                >
                  <Trash2 size={18} />
                </button>
              </div>
              <h3 className="mb-3 text-[#3E2F1F]">
                {doc.title}
              </h3>
              <div className="flex items-start gap-2 text-[#5A4A3A]">
                <FileText
                  size={18}
                  className="flex-shrink-0 mt-1"
                />
                <p className="text-sm leading-relaxed">
                  {doc.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {docs.length === 0 && (
        <div className="text-center py-16 bg-white rounded-lg border-2 border-dashed border-[#D4A574]">
          <Upload
            size={48}
            className="mx-auto mb-4 text-[#A0826D]"
          />
          <p className="text-[#5A4A3A]">
            Belum ada dokumentasi. Klik tombol di atas untuk
            menambahkan.
          </p>
        </div>
      )}
    </div>
  );
}