import { Users } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";

interface Member {
  id: string;
  name: string;
  position: string;
  tenure: string;
  imageUrl: string;
}

export function Anggota() {
  const [selectedMembers, setSelectedMembers] = useState<Set<string>>(new Set());

  const toggleMemberDetail = (id: string) => {
    setSelectedMembers((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const members: Member[] = [
    {
      id: "1",
      name: "Supriono",
      position: "Lurah",
      tenure: "2025 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-clipart/20230215/original/pngtree-avatar-of-a-person-in-a-suit-png-image_8956026.png",
    },
    {
      id: "2",
      name: "drg. Yoshida",
      position: "Puskesmas Kelurahan",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-vector/20240519/ourmid/pngtree-hijab-women-wear-black-suits-and-white-shirts-png-image_12494162.png",
    },
    {
      id: "3",
      name: "Ucok Soriandalan Lubis",
      position: "Satlak PTSP Kelurahan",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-clipart/20230215/original/pngtree-avatar-of-a-person-in-a-suit-png-image_8956026.png",
    },
    {
      id: "4",
      name: "Lestari Sri Utami Dewi",
      position: "Satpel Dukcapil",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-vector/20240519/ourmid/pngtree-hijab-women-wear-black-suits-and-white-shirts-png-image_12494162.png",
    },
    {
      id: "5",
      name: "Jepri Jupriadi",
      position: "Satgas POP PP Kelurahan",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-clipart/20230215/original/pngtree-avatar-of-a-person-in-a-suit-png-image_8956026.png",
    },
    {
      id: "6",
      name: "Hardie",
      position: "Kasi Pemerintahan & Trantib",
      tenure: "2024 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-clipart/20230215/original/pngtree-avatar-of-a-person-in-a-suit-png-image_8956026.png",
    },
    {
      id: "7",
      name: "Tri Endah Widyati",
      position: "Kasi Kesejahteraan Rakyat",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-vector/20240519/ourmid/pngtree-hijab-women-wear-black-suits-and-white-shirts-png-image_12494162.png",
    },
    {
      id: "8",
      name: "Wuri Mahanani",
      position: "Kasi Ekonomi,Pembangunan & Lingkungan Hidup",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-vector/20240519/ourmid/pngtree-hijab-women-wear-black-suits-and-white-shirts-png-image_12494162.png",
    },
    {
      id: "9",
      name: "Robby Alamsyah",
      position: "staf sekertariat",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-clipart/20230215/original/pngtree-avatar-of-a-person-in-a-suit-png-image_8956026.png",
    },
    {
      id: "10",
      name: "Dian Surya Lesmana",
      position: "staf sekertariat",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-vector/20240519/ourmid/pngtree-hijab-women-wear-black-suits-and-white-shirts-png-image_12494162.png",
    },
    {
      id: "11",
      name: "Aries Prasetyo",
      position: "Staf",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-clipart/20230215/original/pngtree-avatar-of-a-person-in-a-suit-png-image_8956026.png",
    },
    {
      id: "12",
      name: "Ratna Susilowati",
      position: "Staf",
      tenure: "2023 - sekarang",
      imageUrl:
        "https://png.pngtree.com/png-vector/20240519/ourmid/pngtree-hijab-women-wear-black-suits-and-white-shirts-png-image_12494162.png",
    },
    
     
      

     
  ];

  return (
    <div className="space-y-6 md:space-y-8">
      {/* Header */}
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <motion.div
          className="flex items-center justify-center gap-3 mb-4"
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
          >
            <Users size={40} className="text-[#8B6F47]" />
          </motion.div>
          <h2 className="text-2xl sm:text-3xl text-[#3E2F1F]">
            Anggota Kelurahan
          </h2>
        </motion.div>
        <p className="text-sm sm:text-base text-[#5A4A3A] max-w-2xl mx-auto">
          Struktur organisasi dan anggota Kelurahan Cipete
          Selatan
        </p>
      </motion.div>

      {/* Lurah Section */}
      <motion.div
        className="bg-white rounded-lg shadow-lg p-8 border-2 border-[#D4A574]"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <motion.h3
          className="text-xl sm:text-2xl text-[#3E2F1F] mb-6 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          Lurah Cipete Selatan
        </motion.h3>
        <div className="flex flex-col items-center">
          <motion.div
            className="relative group mb-6 cursor-pointer"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
            onClick={() => toggleMemberDetail(members[0].id)}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-[#8B6F47] to-[#D4A574] rounded-full blur-lg opacity-50"
              animate={{
                opacity: [0.5, 0.7, 0.5],
                scale: [1, 1.1, 1],
              }}
              transition={{ duration: 3, repeat: Infinity }}
            ></motion.div>
            <motion.img
              src={members[0].imageUrl}
              alt={members[0].name}
              className="relative w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 rounded-full object-cover border-4 border-[#8B6F47] shadow-lg"
              initial={{ rotate: -10, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            />
          </motion.div>
          <motion.h4
            className="text-xl sm:text-2xl text-[#3E2F1F] mb-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            {members[0].name}
          </motion.h4>
          <AnimatePresence>
            {selectedMembers.has(members[0].id) && (
              <>
                <motion.p
                  className="text-[#8B6F47] mb-2"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  {members[0].position}
                </motion.p>
                <motion.p
                  className="text-[#5A4A3A] text-sm"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3, delay: 0.1 }}
                >
                  Masa Jabatan: {members[0].tenure}
                </motion.p>
              </>
            )}
          </AnimatePresence>
          {!selectedMembers.has(members[0].id) && (
            <motion.p
              className="text-[#A0826D] text-sm italic mt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              Klik foto untuk melihat detail
            </motion.p>
          )}
        </div>
      </motion.div>

      {/* Staff Section */}
      <motion.div
        className="bg-white rounded-lg shadow-lg p-8 border-2 border-[#D4A574]"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
      >
        <motion.h3
          className="text-xl sm:text-2xl text-[#3E2F1F] mb-6 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          Staff Kelurahan
        </motion.h3>
        <div className="flex flex-wrap justify-center gap-6">
          {members.slice(1).map((member, index) => (
            <motion.div
              key={member.id}
              className="bg-[#F5E6D3] rounded-lg p-6 border-2 border-[#D4A574] group w-full md:w-[calc(50%-12px)] lg:w-[calc(33.333%-16px)] cursor-pointer"
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{
                duration: 0.5,
                delay: 0.8 + index * 0.1,
                type: "spring",
                stiffness: 100,
              }}
              whileHover={{
                scale: 1.05,
                boxShadow: "0 20px 25px -5px rgba(139, 111, 71, 0.3)",
                borderColor: "#8B6F47",
              }}
              onClick={() => toggleMemberDetail(member.id)}
            >
              <motion.div
                className="relative mb-4"
                whileHover={{ rotate: [0, -5, 5, 0] }}
                transition={{ duration: 0.5 }}
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-[#8B6F47] to-[#D4A574] rounded-full blur-md opacity-30"
                  whileHover={{ opacity: 0.6, scale: 1.1 }}
                  transition={{ duration: 0.3 }}
                ></motion.div>
                <motion.img
                  src={member.imageUrl}
                  alt={member.name}
                  className="relative w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 rounded-full object-cover border-4 border-[#8B6F47] shadow-md mx-auto"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                />
              </motion.div>
              <div className="text-center">
                <motion.h4
                  className="text-lg text-[#3E2F1F] mb-2"
                  whileHover={{ scale: 1.05 }}
                >
                  {member.name}
                </motion.h4>
                <AnimatePresence>
                  {selectedMembers.has(member.id) ? (
                    <>
                      <motion.p
                        className="text-[#8B6F47] text-sm mb-2"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        {member.position}
                      </motion.p>
                      <motion.p
                        className="text-[#5A4A3A] text-xs"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3, delay: 0.1 }}
                      >
                        Masa Jabatan: {member.tenure}
                      </motion.p>
                    </>
                  ) : (
                    <motion.p
                      className="text-[#A0826D] text-xs italic"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      Klik untuk melihat detail
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}