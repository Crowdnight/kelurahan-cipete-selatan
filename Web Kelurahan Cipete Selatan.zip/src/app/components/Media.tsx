import { CreditCard, ShieldAlert, CheckCircle, Search, ExternalLink, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const stepVariants = {
  initial: { opacity: 0, x: -20 },
  animate: { opacity: 1, x: 0 },
  transition: { duration: 0.4 }
};

export function Media() {
  const [ktpOpen, setKtpOpen] = useState(false);
  const [cyberBullyingOpen, setCyberBullyingOpen] = useState(false);
  const [cekNikOpen, setCekNikOpen] = useState(false);

  return (
    <div className="space-y-6 md:space-y-8">
      <motion.h2
        className="text-2xl sm:text-3xl text-[#3E2F1F]"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        Media & Informasi
      </motion.h2>

      {/* KTP Section */}
      <motion.div
        className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#8B6F47]"
        {...fadeInUp}
      >
        <motion.div
          className="flex items-center justify-between gap-3 cursor-pointer"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          onClick={() => setKtpOpen(!ktpOpen)}
        >
          <div className="flex items-center gap-3">
            <motion.div
              className="bg-[#8B6F47] text-white p-3 rounded-lg"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <CreditCard size={28} />
            </motion.div>
            <h3 className="text-xl sm:text-2xl text-[#3E2F1F]">Langkah-langkah Membuat KTP</h3>
          </div>
          <motion.div
            animate={{ rotate: ktpOpen ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronDown size={24} className="text-[#8B6F47]" />
          </motion.div>
        </motion.div>

        <AnimatePresence>
          {ktpOpen && (
            <motion.div
              className="space-y-4 mt-6"
              variants={staggerContainer}
              initial="initial"
              animate="animate"
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              1
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Persiapan Dokumen</h4>
              <p className="text-[#5A4A3A]">
                Siapkan Kartu Keluarga (KK) asli dan fotokopi, serta fotokopi akta kelahiran atau ijazah.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              2
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Datang ke Kelurahan</h4>
              <p className="text-[#5A4A3A]">
                Datang ke kantor Kelurahan Cipete Selatan dengan membawa dokumen yang sudah disiapkan.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              3
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Mengisi Formulir</h4>
              <p className="text-[#5A4A3A]">
                Isi formulir permohonan KTP dengan lengkap dan benar. Petugas akan membantu jika ada kesulitan.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              4
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Foto dan Tanda Tangan Digital</h4>
              <p className="text-[#5A4A3A]">
                Lakukan pengambilan foto dan tanda tangan digital di loket yang telah disediakan.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              5
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Proses Verifikasi</h4>
              <p className="text-[#5A4A3A]">
                Dokumen akan diverifikasi oleh petugas. Pastikan semua data sudah benar.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#8B6F47] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              <CheckCircle size={20} />
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Pengambilan KTP</h4>
              <p className="text-[#5A4A3A]">
                KTP elektronik akan selesai dalam 14 hari kerja dan dapat diambil di kelurahan dengan membawa tanda terima.
              </p>
            </div>
          </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Cyber Bullying Section */}
      <motion.div
        className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#D4A574]"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <motion.div
          className="flex items-center justify-between gap-3 cursor-pointer"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          onClick={() => setCyberBullyingOpen(!cyberBullyingOpen)}
        >
          <div className="flex items-center gap-3">
            <motion.div
              className="bg-[#D4A574] text-white p-3 rounded-lg"
              whileHover={{ scale: 1.1, rotate: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <ShieldAlert size={28} />
            </motion.div>
            <h3 className="text-xl sm:text-2xl text-[#3E2F1F]">Pelaporan Kasus Cyber Bullying</h3>
          </div>
          <motion.div
            animate={{ rotate: cyberBullyingOpen ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronDown size={24} className="text-[#D4A574]" />
          </motion.div>
        </motion.div>

        <AnimatePresence>
          {cyberBullyingOpen && (
            <motion.div
              className="space-y-4 mt-6"
              variants={staggerContainer}
              initial="initial"
              animate="animate"
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              1
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Kumpulkan Bukti</h4>
              <p className="text-[#5A4A3A]">
                Screenshot atau simpan semua bukti digital seperti chat, komentar, atau postingan yang mengandung perundungan.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              2
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Lapor ke RT/RW</h4>
              <p className="text-[#5A4A3A]">
                Laporkan kasus ke ketua RT/RW setempat sebagai langkah awal. Mereka akan membantu proses selanjutnya.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              3
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Datang ke Kelurahan</h4>
              <p className="text-[#5A4A3A]">
                Bawa bukti-bukti dan surat pengantar dari RT/RW ke kantor Kelurahan Cipete Selatan.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              4
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Isi Form Laporan</h4>
              <p className="text-[#5A4A3A]">
                Lengkapi formulir pelaporan dengan detail kejadian, identitas pelapor dan terlapor (jika diketahui).
              </p>
            </div>
          </motion.div>

          <motion.div
            className="flex gap-4"
            variants={stepVariants}
            whileHover={{ x: 10, backgroundColor: "#FFF9F0" }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="flex-shrink-0 w-10 h-10 bg-[#D4A574] text-white rounded-full flex items-center justify-center"
              whileHover={{ scale: 1.2, rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              5
            </motion.div>
            <div className="flex-1">
              <h4 className="mb-2 text-[#3E2F1F]">Koordinasi dengan Pihak Berwenang</h4>
              <p className="text-[#5A4A3A]">
                Kelurahan akan membantu koordinasi dengan kepolisian atau instansi terkait untuk penanganan lebih lanjut.
              </p>
            </div>
          </motion.div>

          <motion.div
            className="bg-[#FFF3E0] border-l-4 border-[#FF9800] p-4 mt-6"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            whileHover={{ scale: 1.02 }}
          >
            <p className="text-[#5A4A3A]">
              <strong className="text-[#3E2F1F]">Penting:</strong> Jangan balas atau provokasi pelaku.
              Segera laporkan untuk mendapatkan perlindungan hukum yang tepat.
            </p>
          </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Cek NIK Section */}
      <motion.div
        className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#8B6F47]"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <motion.div
          className="flex items-center justify-between gap-3 cursor-pointer"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          onClick={() => setCekNikOpen(!cekNikOpen)}
        >
          <div className="flex items-center gap-3">
            <motion.div
              className="bg-[#8B6F47] text-white p-3 rounded-lg"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Search size={28} />
            </motion.div>
            <h3 className="text-xl sm:text-2xl text-[#3E2F1F]">Cek Data NIK</h3>
          </div>
          <motion.div
            animate={{ rotate: cekNikOpen ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronDown size={24} className="text-[#8B6F47]" />
          </motion.div>
        </motion.div>

        <AnimatePresence>
          {cekNikOpen && (
            <motion.div
              className="space-y-4 mt-6"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
          <p className="text-[#5A4A3A]">
            Anda dapat mengecek validitas dan data NIK (Nomor Induk Kependudukan) melalui website resmi Dinas Kependudukan dan Pencatatan Sipil DKI Jakarta.
          </p>

          <div className="bg-[#F5E6D3] rounded-lg p-6 border-2 border-[#D4A574]">
            <h4 className="mb-3 text-[#3E2F1F]">Layanan yang Tersedia:</h4>
            <ul className="space-y-2 text-[#5A4A3A] list-disc list-inside">
              <li>Cek validitas NIK</li>
              <li>Cek status KTP Elektronik</li>
              <li>Informasi data kependudukan</li>
              <li>Verifikasi dokumen kependudukan</li>
            </ul>
          </div>

          <motion.a
            href="https://datawarga-dukcapil.jakarta.go.id/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#8B6F47] text-white px-4 sm:px-6 py-3 rounded-lg hover:bg-[#6B5744] transition-colors shadow-lg text-sm sm:text-base"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Search size={18} className="sm:w-5 sm:h-5" />
            <span className="whitespace-nowrap">Cek NIK di Data Warga Jakarta</span>
            <ExternalLink size={16} className="sm:w-[18px] sm:h-[18px]" />
          </motion.a>

          <div className="bg-[#E3F2FD] border-l-4 border-[#2196F3] p-4 mt-4">
            <p className="text-[#5A4A3A] text-sm">
              <strong className="text-[#3E2F1F]">Catatan:</strong> Pastikan Anda mengakses website resmi pemerintah.
              Jangan memberikan data pribadi NIK Anda ke website yang tidak terpercaya.
            </p>
          </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
