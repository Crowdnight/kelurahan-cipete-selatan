import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Eye, EyeOff, LogIn } from "lucide-react";
import logoJakarta from "../../imports/image-0.png";

const USERS = [
  { username: "azzam123", password: "rpl2" },
  { username: "abyan123", password: "rpl2" },
  { username: "eko123", password: "rpl2" },
];

export function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (localStorage.getItem("cipsel_logged_in")) {
      navigate("/", { replace: true });
    }
  }, []);

  function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    setTimeout(() => {
      const valid = USERS.find(
        (u) => u.username === username.trim() && u.password === password
      );

      if (valid) {
        localStorage.setItem("cipsel_logged_in", "true");
        localStorage.setItem("cipsel_user", valid.username);
        navigate("/", { replace: true });
      } else {
        setError("Username atau password salah. Silakan coba lagi.");
        setLoading(false);
      }
    }, 600);
  }

  return (
    <div className="min-h-screen relative flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://i.ibb.co.com/gZLRg0ZP/Whats-App-Image-2026-04-08-at-15-06-15-1.jpg')`,
        }}
      />
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />

      {/* Decorative blurred circles */}
      <div className="absolute top-10 left-10 w-64 h-64 rounded-full bg-[#8B6F47]/30 blur-3xl" />
      <div className="absolute bottom-10 right-10 w-72 h-72 rounded-full bg-[#D4A574]/20 blur-3xl" />

      {/* Login card */}
      <motion.div
        className="relative z-10 w-full max-w-md mx-4"
        initial={{ opacity: 0, y: 40, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 shadow-2xl overflow-hidden">
          {/* Card header */}
          <div className="bg-gradient-to-r from-[#8B6F47] to-[#6B5744] px-8 py-6 flex flex-col items-center gap-3">
            <img
              src={logoJakarta}
              alt="Logo Jakarta"
              className="h-16 w-auto object-contain drop-shadow-lg"
            />
            <div className="text-center text-white">
              <h1 className="text-xl sm:text-2xl">Kelurahan Cipete Selatan</h1>
              <p className="text-[#F5E6D3] text-sm mt-1">
                Kota Administrasi Jakarta Selatan
              </p>
            </div>
          </div>

          {/* Form */}
          <div className="px-8 py-8">
            <h2 className="text-white text-center text-lg mb-6 tracking-wide">
              Masuk ke web Kelurahan
            </h2>

            <form onSubmit={handleLogin} className="space-y-5">
              {/* Username */}
              <div>
                <label className="block text-[#F5E6D3] text-sm mb-2">
                  Username
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Masukkan username"
                  required
                  className="w-full bg-white/10 border border-white/30 text-white placeholder-white/40 rounded-lg px-4 py-3 outline-none focus:border-[#D4A574] focus:bg-white/15 transition-all"
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-[#F5E6D3] text-sm mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Masukkan password"
                    required
                    className="w-full bg-white/10 border border-white/30 text-white placeholder-white/40 rounded-lg px-4 py-3 pr-12 outline-none focus:border-[#D4A574] focus:bg-white/15 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Error */}
              {error && (
                <motion.p
                  className="text-red-300 text-sm text-center bg-red-900/30 rounded-lg px-3 py-2 border border-red-500/30"
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {error}
                </motion.p>
              )}

              {/* Submit */}
              <motion.button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-[#8B6F47] to-[#A0826D] hover:from-[#7A5F3A] hover:to-[#8B6F47] text-white rounded-lg px-4 py-3 flex items-center justify-center gap-2 transition-all disabled:opacity-70 shadow-lg"
                whileTap={{ scale: 0.97 }}
              >
                {loading ? (
                  <motion.div
                    className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                  />
                ) : (
                  <>
                    <LogIn size={18} />
                    <span>Masuk</span>
                  </>
                )}
              </motion.button>
            </form>

            <p className="text-white/30 text-xs text-center mt-6">
              © 2026 Kelurahan Cipete Selatan
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
