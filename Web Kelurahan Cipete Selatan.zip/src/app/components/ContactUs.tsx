import { Phone, Mail, MapPin, Clock, MessageSquare, Send } from "lucide-react";
import { useState } from "react";

export function ContactUs() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Compose email
    const emailTo = "cipeteselatan@jakarta.go.id";
    const emailSubject = `[Kritik & Saran] ${formData.subject} - ${formData.name}`;
    const emailBody = `Nama: ${formData.name}
Email: ${formData.email}
Kategori: ${formData.subject}

Pesan:
${formData.message}

---
Dikirim melalui website Kelurahan Cipete Selatan`;

    // Open email client with pre-filled data
    const mailtoLink = `mailto:${emailTo}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    window.location.href = mailtoLink;

    // Show success message
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: "", email: "", subject: "", message: "" });
    }, 3000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="space-y-6 md:space-y-8">
      <h2 className="text-2xl sm:text-3xl text-[#3E2F1F]">Hubungi Kami</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Contact Info Cards */}
        <div className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#8B6F47]">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-[#8B6F47] text-white p-4 rounded-lg">
              <Phone size={32} />
            </div>
            <div>
              <h3 className="text-xl text-[#3E2F1F]">Telepon Kantor</h3>
              <p className="text-[#5A4A3A]">Hubungi kami melalui telepon</p>
            </div>
          </div>
          <a
            href="tel:+622175906001"
            className="text-2xl text-[#8B6F47] hover:text-[#6B5744] transition-colors"
          >
           (021)7692042(Kelurahan Cipsel)
            <br />
            089652982682(PTSP)
          </a>
          <p className="text-sm text-[#5A4A3A] mt-2">
            Senin - Jumat: 08.00 - 16.00 WIB
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#D4A574]">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-[#D4A574] text-white p-4 rounded-lg">
              <Mail size={32} />
            </div>
            <div>
              <h3 className="text-xl text-[#3E2F1F]">Instagram</h3>
              <p className="text-[#5A4A3A]">Hubungi kami via Instagram</p>
            </div>
          </div>
          <div className="space-y-2">
            <a
              href="https://www.instagram.com/kelurahancipeteselatan/"
              target="_blank"
              rel="noopener noreferrer"
              className="block text-base sm:text-lg md:text-xl text-[#8B6F47] hover:text-[#6B5744] transition-colors break-words"
            >
              @kelurahancipeteselatan
            </a>
            <a
              href="https://www.instagram.com/ptsp_cipsel/"
              target="_blank"
              rel="noopener noreferrer"
              className="block text-base sm:text-lg md:text-xl text-[#8B6F47] hover:text-[#6B5744] transition-colors break-words"
            >
              @ptsp_cipsel
            </a>
            <a
              href="https://www.instagram.com/pkk_kelcipsel/"
              target="_blank"
              rel="noopener noreferrer"
              className="block text-base sm:text-lg md:text-xl text-[#8B6F47] hover:text-[#6B5744] transition-colors break-words"
            >
              @pkk_kelcipsel
            </a>
          </div>
          <p className="text-sm text-[#5A4A3A] mt-4">
            Kirim pesan melalui Direct Message (DM)
          </p>
        </div>
      </div>

      {/* Address Section */}
      <div className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#8B6F47]">
        <div className="flex items-start gap-4 mb-6">
          <div className="bg-[#8B6F47] text-white p-4 rounded-lg">
            <MapPin size={32} />
          </div>
          <div className="flex-1">
            <h3 className="text-xl mb-2 text-[#3E2F1F]">Alamat Kantor</h3>
            <p className="text-[#5A4A3A] leading-relaxed">
              Jl. Palem No. 17 A<br />
              Cipete Selatan<br />
              Kecamatan Cilandak<br />
              RT12/RW3<br />
              Kota Administrasi Jakarta Selatan<br />
              DKI Jakarta 12410
            </p>
          </div>
        </div>
      </div>

      {/* Operating Hours */}
      <div className="bg-[#D4A574] rounded-lg shadow-lg p-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="bg-white text-[#8B6F47] p-4 rounded-lg">
            <Clock size={32} />
          </div>
          <h3 className="text-xl text-white">Jam Operasional</h3>
        </div>
        <div className="space-y-3 text-white">
          <div className="flex justify-between items-center p-3 bg-white/20 rounded-lg">
            <span>Senin - Kamis</span>
            <span>08.00 - 16.00 WIB</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-white/20 rounded-lg">
            <span>Jumat</span>
            <span>08.00 - 16.30 WIB</span>
          </div>
          <div className="flex justify-between items-center p-3 bg-white/20 rounded-lg">
            <span>Sabtu - Minggu</span>
            <span>Tutup</span>
          </div>
        </div>
        <div className="mt-6 p-4 bg-white/10 rounded-lg">
          <p className="text-sm text-white">
            <strong>Catatan:</strong> Pada hari libur nasional, kantor kelurahan tutup.
            Untuk pelayanan darurat, silakan hubungi nomor telepon di atas.
          </p>
        </div>
      </div>

      {/* Map Section */}
      <div className="bg-white rounded-lg shadow-lg p-4 sm:p-6 md:p-8 border-2 border-[#D4A574]">
        <h3 className="mb-4 text-lg sm:text-xl text-[#3E2F1F]">Lokasi Kami</h3>

        <div className="w-full h-64 sm:h-80 md:h-96 rounded-lg overflow-hidden border-2 border-[#D4A574]">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.8449999999997!2d106.7989!3d-6.2829!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f1ed4db0b5e3%3A0x5e9a5e9a5e9a5e9a!2sJl.%20Palem%20No.17A%2C%20Cipete%20Sel.%2C%20Kec.%20Cilandak%2C%20Kota%20Jakarta%20Selatan%2C%20Daerah%20Khusus%20Ibukota%20Jakarta%2012410!5e0!3m2!1sid!2sid!4v1234567890123!5m2!1sid!2sid"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Lokasi Kelurahan Cipete Selatan"
          ></iframe>
        </div>
      </div>

      {/* Kritik dan Saran Form */}
      <div className="bg-white rounded-lg shadow-lg p-8 border-l-4 border-[#8B6F47]">
        <div className="flex items-center gap-4 mb-6">
          <div className="bg-[#8B6F47] text-white p-4 rounded-lg">
            <MessageSquare size={32} />
          </div>
          <div>
            <h3 className="text-2xl text-[#3E2F1F]">Kritik dan Saran</h3>
            <p className="text-[#5A4A3A]">Sampaikan kritik dan saran Anda untuk kami</p>
          </div>
        </div>

        {submitted && (
          <div className="mb-6 p-4 bg-green-100 border-l-4 border-green-500 rounded-lg">
            <p className="text-green-700">
              Terima kasih! Email client Anda akan terbuka dengan kritik dan saran yang sudah terisi. Silakan klik tombol "Send" untuk mengirim ke email kelurahan.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block mb-2 text-[#3E2F1F]">
                Nama Lengkap <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] transition-colors bg-white text-[#3E2F1F]"
                placeholder="Masukkan nama lengkap Anda"
              />
            </div>

            <div>
              <label htmlFor="email" className="block mb-2 text-[#3E2F1F]">
                Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] transition-colors bg-white text-[#3E2F1F]"
                placeholder="nama@email.com"
              />
            </div>
          </div>

          <div>
            <label htmlFor="subject" className="block mb-2 text-[#3E2F1F]">
              Kategori <span className="text-red-500">*</span>
            </label>
            <select
              id="subject"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] transition-colors bg-white text-[#3E2F1F]"
            >
              <option value="">Pilih kategori...</option>
              <option value="pelayanan">Pelayanan</option>
              <option value="infrastruktur">Infrastruktur</option>
              <option value="kebersihan">Kebersihan</option>
              <option value="keamanan">Keamanan</option>
              <option value="administrasi">Administrasi</option>
              <option value="lainnya">Lainnya</option>
            </select>
          </div>

          <div>
            <label htmlFor="message" className="block mb-2 text-[#3E2F1F]">
              Kritik dan Saran <span className="text-red-500">*</span>
            </label>
            <textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
              rows={6}
              className="w-full px-4 py-3 border-2 border-[#D4A574] rounded-lg focus:outline-none focus:border-[#8B6F47] transition-colors resize-none bg-white text-[#3E2F1F]"
              placeholder="Tuliskan kritik dan saran Anda di sini..."
            />
          </div>

          <button
            type="submit"
            className="w-full md:w-auto px-8 py-3 bg-[#8B6F47] text-white rounded-lg hover:bg-[#6B5744] transition-colors flex items-center justify-center gap-2 shadow-lg"
          >
            <Send size={20} />
            <span>Kirim Kritik dan Saran</span>
          </button>
        </form>

        <div className="mt-6 p-4 bg-[#F5E6D3] rounded-lg border border-[#D4A574]">
          <p className="text-sm text-[#5A4A3A]">
            <strong>Catatan:</strong> Kritik dan saran Anda sangat berharga bagi kami untuk meningkatkan kualitas pelayanan.
            Setelah klik tombol "Kirim", email client Anda akan terbuka dengan data yang sudah terisi. Anda tinggal klik "Send" untuk mengirim ke email <strong>cipeteselatan@jakarta.go.id</strong>
          </p>
        </div>
      </div>
    </div>
  );
}
